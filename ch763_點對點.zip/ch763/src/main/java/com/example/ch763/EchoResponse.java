package com.example.ch763;

public class EchoResponse {
    private String msg;

    public EchoResponse(String msg) {
        this.msg = msg;
    }


    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
