package com.example.ch763;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;

@Controller
@SpringBootApplication
public class Ch763Application {

    public static void main(String[] args) {
        SpringApplication.run(Ch763Application.class, args);
    }

    @MessageMapping("/welcome")
    @SendTo("/echo/getResponse")
    public EchoResponse echo(EchoMessage message ) throws Exception {
        Thread.sleep(3000);
        return new EchoResponse("Welcome, " + message.getName());
    }

    @Autowired
    SimpMessagingTemplate simpMessagingTemplate;

    @MessageMapping("/chat")
    @SendTo("/echo/getChat")
    public EchoResponse chat(Principal principal, String message) {
        String user = (principal.getName() == "aaa") ? "bbb" : "aaa";
        String value = principal.getName() + "-send:" +  message;
        simpMessagingTemplate.convertAndSendToUser(user,"/pp/msg", value);
        return new EchoResponse(value);
    }
}
